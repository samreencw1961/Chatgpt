(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_116e8a94._.js",
  "static/chunks/node_modules_@assistant-ui_react_dist_40758cfa._.js",
  "static/chunks/node_modules_assistant-stream_dist_f2dc3e13._.js",
  "static/chunks/node_modules_zod_v3_209a51fb._.js",
  "static/chunks/node_modules_zod-to-json-schema_dist_esm_629c8730._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_36a4b45d._.js",
  "static/chunks/node_modules_@radix-ui_21b02f02._.js",
  "static/chunks/node_modules_@floating-ui_9ec1fa39._.js",
  "static/chunks/node_modules_d65ac79e._.js",
  "static/chunks/node_modules_@assistant-ui_react-markdown_styles_dot_83a3e0f6.css"
],
    source: "dynamic"
});
